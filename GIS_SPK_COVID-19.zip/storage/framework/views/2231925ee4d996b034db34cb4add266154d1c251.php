<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <script src="https://kit.fontawesome.com/15181efa86.js" crossorigin="anonymous"></script>
    <script src="js/lazysizes.min.js" async></script>
    <title>PETA PENYEBARAN COVID-19 DI KOTA PALEMBANG</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=AIzaSyAw0dLuWC0-tg-Qr9GUJ46gpxfahlqZA0Y"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      #map {
        height: 250px;
        width: 100%;
      }
      
    </style>
    <!-- Custom styles for this template -->
    <link href="css/vote.css" rel="stylesheet">
  </head>
  <body onload="initMap()">
  <header>
  
  <div class="navbar navbar-dark bg-danger shadow-sm">
    <div class="container d-flex justify-content-center justify-content-md-between" style="color:white">
      <a class="navbar-brand d-flex align-items-center" >
        <i class="fas fa-person-booth"></i>
        <strong style="padding-bottom:2px">&nbspPETA PENYEBARAN COVID-19&nbsp</strong>
      </a>
    </div>
  </div>
  </header>

  <section class="jumbotron text-center">
    <div class="container">
      <h1 class="jumbotron-heading"><b>PENYEBARAN COVID-19 KOTA PALEMBANG</b></h1>
      <!-- <p class="judul" style="color:#2793DA"></p> -->
      <p></p>
    </div>
  </section>

<main role="main">

  <!-- Nominasi Teramah -->
  <div class="album py-5" style="background-color: #f7f7f7">
    <div class="container">
      <h1 class="jumbotron-heading-nominasi"><a style="box-shadow: .1rem .1rem .5rem #FFAEBC;">Peta Penyebaran</a></h1>

      <row>
        <div id="map"></div>
          <b><div id="info-box"><span>*Arahkan Mouse Anda Ke area yang ingin anda lihat</span></div></b>
          <div id="tingkat"></div>
      </row>
      <br><br>

      <h1 class="jumbotron-heading-nominasi"><a style="box-shadow: .1rem .1rem .5rem #FFAEBC;">Data Penyebaran</a></h1>
      <div class="row">
        <div class="col-lg-12">
          <div style="overflow-x:auto;">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Kecamatan</th>
                      <th scope="col">ODP Proses</th>
                      <th scope="col">ODP Selesai</th>
                      <th scope="col">PDP Proses</th>
                      <th scope="col">PDP Negatif</th>
                      <th scope="col">Dirawat</th>
                      <th scope="col">Sembuh</th>
                      <th scope="col">Meninggal</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    for($i=0;$i<19;$i++){
                    ?>
                    <tr>
                      <th scope="row"><?php echo e($i+1); ?></th>
                      <td id="kec_<?php echo e($i); ?>"></td>
                      <td id="odp1_<?php echo e($i); ?>"></td>
                      <td id="odp2_<?php echo e($i); ?>"></td>
                      <td id="pdp1_<?php echo e($i); ?>"></td>
                      <td id="pdp2_<?php echo e($i); ?>"></td>
                      <td id="rawat_<?php echo e($i); ?>"></td>
                      <td id="sembuh_<?php echo e($i); ?>"></td>
                      <td id="meninggal_<?php echo e($i); ?>"></td>
                    </tr>
                  <?php }
                  ?>
                  </tbody>
                </table>
              </div>
        </div>
      </div>

      <br><br>

      <h1 class="jumbotron-heading-nominasi"><a style="box-shadow: .1rem .1rem .5rem #FFAEBC;">DSS Dengan Metode SAW</a></h1>
      <div class="row">

        <div class="col-lg-3">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal0">
            Lihat Tabel Kriteria
          </button>
        </div>

        <div class="col-lg-3">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            Lihat Tabel Analisa
          </button>
        </div>

        <div class="col-lg-3">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">
            Lihat Tabel Normalisasi
          </button>
        </div>

        <div class="col-lg-3">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal3">
            Lihat Tabel Ranking
          </button>
        </div>

      </div>

      <!-- Modal -->
      <div class="modal fade" id="exampleModal0" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tabel Kriteria</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">

              <div class ="justify-content-center">
                <img src="img/krit1.png">
                <img src="img/krit2.png">
                <img src="img/krit3.png">
                <img src="img/krit4.png">
              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tabel Analisa</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div style="overflow-x:auto;">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Alternatif</th>
                      <th scope="col">C1</th>
                      <th scope="col">C2</th>
                      <th scope="col">C3</th>
                      <th scope="col">C4</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    for($i=0;$i<19;$i++){
                    ?>
                    <tr>
                      <th scope="row"><?php echo e($i+1); ?></th>
                      <td id="1kec_<?php echo e($i); ?>"></td>
                      <td id="1c1<?php echo e($i); ?>"></td>
                      <td id="1c2<?php echo e($i); ?>"></td>
                      <td id="1c3<?php echo e($i); ?>"></td>
                      <td id="1c4<?php echo e($i); ?>"></td>
                    </tr>
                  <?php }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal -->
      <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tabel Normalisasi</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div style="overflow-x:auto;">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Alternatif</th>
                      <th scope="col">C1</th>
                      <th scope="col">C2</th>
                      <th scope="col">C3</th>
                      <th scope="col">C4</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    for($i=0;$i<19;$i++){
                    ?>
                    <tr>
                      <th scope="row"><?php echo e($i+1); ?></th>
                      <td id="2kec_<?php echo e($i); ?>"></td>
                      <td id="2c1<?php echo e($i); ?>"></td>
                      <td id="2c2<?php echo e($i); ?>"></td>
                      <td id="2c3<?php echo e($i); ?>"></td>
                      <td id="2c4<?php echo e($i); ?>"></td>
                    </tr>
                  <?php }
                  ?>
                  </tbody>
                </table>
              </div>            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tabel Ranking</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div style="overflow-x:auto;">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Alternatif</th>
                      <th scope="col">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    for($i=0;$i<19;$i++){
                    ?>
                    <tr>
                      <th scope="row"><?php echo e($i+1); ?></th>
                      <td id="3kec_<?php echo e($i); ?>"></td>
                      <td id="3c1<?php echo e($i); ?>"></td>
                    </tr>
                  <?php }
                  ?>
                  </tbody>
                </table>
              </div>           
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

     

    </div>
  </div>

</main>

<footer class="text-muted">
  <div class="container">
    <p><a href="#" class="backtop">Back to top</a></p>
    <p>
      <a> © 2021 Hafizh Zahran.  All rights reserved. &nbsp<a href="https://www.hostingan.id/"></a></a>
    </p>
  </div>
</footer>



<script src="js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>

<script type="text/javascript">
                                                    
    $.ajax({
        url:'http://asuransiastra.my.id/korona.php',
        success:function(result){
          result = JSON.parse(result);
          console.log(result.data);


          for (let i = 0; i < 19; i++){
            //table 1
            $('#kec_'+i).text(result.data.data_counting[i].nama_wilayah);
            $('#odp1_'+i).text(result.data.data_counting[i].detail_odp.odp_proses);
            $('#odp2_'+i).text(result.data.data_counting[i].detail_odp.odp_selesai);
            $('#pdp1_'+i).text(result.data.data_counting[i].detail_pdp.pdp_proses);
            $('#pdp2_'+i).text(result.data.data_counting[i].detail_pdp.pdp_negatif);
            $('#rawat_'+i).text(result.data.data_counting[i].detail_positif.positif_dirawat);
            $('#sembuh_'+i).text(result.data.data_counting[i].detail_positif.positif_sembuh);
            $('#meninggal_'+i).text(result.data.data_counting[i].detail_positif.positif_meninggal);




            //table 2
            $('#1kec_'+i).text(result.data.data_counting[i].nama_wilayah);

            //c1
            var odp_s = result.data.data_counting[i].detail_odp.odp_selesai;
            var odp_p = result.data.data_counting[i].detail_odp.odp_proses;
            var t_odp = odp_s + odp_p;
            var persen_odp = odp_s / t_odp * 100;

            if(persen_odp <= 10){
              persen_odp = 10;
            }
            else if(persen_odp <= 20){
              persen_odp = 20;
            }
            else if(persen_odp <= 30){
              persen_odp = 30;
            }
            else if(persen_odp <= 40){
              persen_odp = 40;
            }
            else if(persen_odp <= 50){
              persen_odp = 50;
            }
            else if(persen_odp <= 60){
              persen_odp = 60;
            }
            else if(persen_odp <= 70){
              persen_odp = 70;
            }
            else if(persen_odp <= 80){
              persen_odp = 80;
            }
            else if(persen_odp <= 90){
              persen_odp = 90;
            }
            else if(persen_odp <= 100){
              persen_odp = 100;
            }

            $('#1c1'+i).text(persen_odp);

            //c2
            var pdp_s = result.data.data_counting[i].detail_pdp.pdp_negatif;
            var pdp_p = result.data.data_counting[i].detail_pdp.pdp_proses;
            var t_pdp = pdp_s + pdp_p;
            var persen_pdp = pdp_s / t_pdp * 100;

            if(persen_pdp <= 10){
              persen_pdp = 10;
            }
            else if(persen_pdp <= 20){
              persen_pdp = 20;
            }
            else if(persen_pdp <= 30){
              persen_pdp = 30;
            }
            else if(persen_pdp <= 40){
              persen_pdp = 40;
            }
            else if(persen_pdp <= 50){
              persen_pdp = 50;
            }
            else if(persen_pdp <= 60){
              persen_pdp = 60;
            }
            else if(persen_pdp <= 70){
              persen_pdp = 70;
            }
            else if(persen_pdp <= 80){
              persen_pdp = 80;
            }
            else if(persen_pdp <= 90){
              persen_pdp = 90;
            }
            else if(persen_pdp <= 100){
              persen_pdp = 100;
            }

            $('#1c2'+i).text(persen_pdp);

            //c3 dan c4
            var sembuh = result.data.data_counting[i].detail_positif.positif_sembuh;
            var rawat = result.data.data_counting[i].detail_positif.positif_dirawat;
            var mati = result.data.data_counting[i].detail_positif.positif_meninggal;
            var total = sembuh + rawat + mati;
            var persen_sembuh = sembuh / total * 100;
            var persen_mati = mati / total * 100;

            if(persen_sembuh <= 10){
              persen_sembuh = 10;
            }
            else if(persen_sembuh <= 20){
              persen_sembuh = 20;
            }
            else if(persen_sembuh <= 30){
              persen_sembuh = 30;
            }
            else if(persen_sembuh <= 40){
              persen_sembuh = 40;
            }
            else if(persen_sembuh <= 50){
              persen_sembuh = 50;
            }
            else if(persen_sembuh <= 60){
              persen_sembuh = 60;
            }
            else if(persen_sembuh <= 70){
              persen_sembuh = 70;
            }
            else if(persen_sembuh <= 80){
              persen_sembuh = 80;
            }
            else if(persen_sembuh <= 90){
              persen_sembuh = 90;
            }
            else if(persen_sembuh <= 100){
              persen_sembuh = 100;
            }

            $('#1c3'+i).text(persen_sembuh);

            if(persen_mati >= 8){
              persen_mati = 10;
            }
            else if(persen_mati <= 8){
              persen_mati = 20;
            }
            else if(persen_mati <= 7){
              persen_mati = 30;
            }
            else if(persen_mati <= 6){
              persen_mati = 40;
            }
            else if(persen_mati <= 5){
              persen_mati = 50;
            }
            else if(persen_mati <= 4){
              persen_mati = 60;
            }
            else if(persen_mati <= 3){
              persen_mati = 70;
            }
            else if(persen_mati <= 2){
              persen_mati = 80;
            }
            else if(persen_mati <= 1){
              persen_mati = 90;
            }
            else if(persen_mati <= 0){
              persen_mati = 100;
            }

            $('#1c4'+i).text(persen_mati);




            //table 3
            $('#2kec_'+i).text(result.data.data_counting[i].nama_wilayah);

            //c1
            var n_c1 = 100 / persen_odp;
            $('#2c1'+i).text(n_c1);

            //C2
            var n_c2 = 100 / persen_pdp;
            $('#2c2'+i).text(n_c2);

            //c1
            var n_c3 = 100 / persen_sembuh;
            $('#2c3'+i).text(n_c3);

            //c1
            var n_c4 = 10 / persen_mati;
            if(n_c4 == "Infinity"){
              n_c4 = 0;
            }
            $('#2c4'+i).text(n_c4);




            //table 4
            $('#3kec_'+i).text(result.data.data_counting[i].nama_wilayah);

            //total
            var total_rank = (n_c1 * 5) + (n_c2 * 10) + (n_c3 * 30) + (n_c4 * 20);
            $('#3c1'+i).text(total_rank);           

          }

          

          
        }
    })

</script>
<script>
      let map;

      function initMap() {
        map = new google.maps.Map(document.getElementById("map"), {
          zoom: 11,
          center: { lat: -2.987227, lng: 104.764566 },
        });
        // Load GeoJSON.
        map.data.loadGeoJson(
          "<?php echo e(url('json').'/map.json'); ?>"
        );
        // Add some style.
        map.data.setStyle((feature) => {
          return /** @type  {google.maps.Data.StyleOptions} */ {
            fillColor: feature.getProperty("color"),
            strokeWeight: 1,
          };
        });

        map.data.addListener("mouseover", (event) => {
        document.getElementById("info-box").textContent = event.feature.getProperty(
        "letter");
        document.getElementById("tingkat").textContent = event.feature.getProperty(
        "bahaya");
  });
        
      }

</script>
</body>
</html>
<?php /**PATH C:\xampp7_4\htdocs\GIS_SPK_COVID-19\resources\views/home.blade.php ENDPATH**/ ?>