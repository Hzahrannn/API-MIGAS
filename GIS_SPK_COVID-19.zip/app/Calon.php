<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Calon extends Model
{
   protected $table='calon_kandidat';
}