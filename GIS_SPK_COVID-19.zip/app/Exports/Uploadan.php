<?php
 
namespace App\Exports;
 
use App\Upload;
use Maatwebsite\Excel\Concerns\FromCollection;
 
class Uploadan implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Upload::all();
    }
}