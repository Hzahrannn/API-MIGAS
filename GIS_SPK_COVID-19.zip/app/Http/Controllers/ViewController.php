<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use App\Exports\Uploadan;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\Controller;
use App\Tools;
use App\Well;
use App\Upload;
use App\Kategori;
use App\User;
use Auth;

class ViewController extends BaseController
{
    public function photos(Request $request)
    {
        $page = $_GET['page'];
        $limit = $_GET['limit'];
        
        if(!empty($_GET['userId'])){
            $userid = $_GET['userId'];
        }
        else{
            $userid;
        }
        
        if(!empty($_GET['dateFrom'])){
            $dateFrom = $_GET['dateFrom'];
        }
        else{
            $dateFrom;
        }
        
        if(!empty($_GET['dateTo'])){
            $dateTo = $_GET['dateTo'];
        }
        else{
            $dateTo;
        }
        
        if(!empty($_GET['category'])){
            $category = $_GET['category'];
        }
        else{
            $category;
        }
        
        if(!empty($_GET['well'])){
            $well = $_GET['well'];
        }
        else{
            $well;
        }
        
        if(!empty($_GET['tool'])){
        $tool = $_GET['tool'];
        }
        else{
            $tool;
        }
        
        if(empty($userid) && empty($dateFrom) && empty($dateTo) && empty($category) && empty($well) && empty($tool)){
            $today = date('Y-m-d');
            $from = date('Y-m-d');
            $to = date('Y-m-d', strtotime('+3 day', strtotime($from)));
            if($page != "1"){
                $total = $page * 2;
                $from = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                $to = date('Y-m-d', strtotime('+2 day', strtotime($from)));
                
            }
            $photo = Upload::whereBetween('waktu', [$from, $to])->select(['id_upload', 'foto','waktu'])->get();
            
            
            $collection = collect();
            foreach ($photo as $invoice) {
                    $collection->push([
                        'id' => $invoice->id_upload,
                        'photo' => $invoice->foto,
                        'date' => $invoice->waktu,
                    ]);
                
            }
            
            $fotos = [];
            foreach ($collection as $key => $value) {
                $fotos[$value['date']]['date'] = $value['date'];
                $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
            }
            
            
        }
        else{
            if(!empty($dateFrom) && !empty($dateTo)){
                if(empty($category) && empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_kategori',$id_kategori)->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && !empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_well)->where('no_sumur',$well_id)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && !empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_well)->where('no_sumur',$well_id)->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && !empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_well)->where('no_sumur',$well_id)->where('id_tools',$id_tools)->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && !empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = $dateFrom;
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_well)->where('no_sumur',$well_id)->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
            }
            
            else{
                if(empty($category) && empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_kategori',$id_kategori)->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && !empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_well)->where('no_sumur',$well_id)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && !empty($well) && empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_sumur)->where('no_sumur',$id_well)->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(!empty($category) && !empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    $kat = Kategori::where('kategori',$category)->first();
                    if(!empty($kat)){
                        $id_kategori = $kat->id_kategori;
                    }
                    else{
                        $id_kategori = "";
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_sumur)->where('no_sumur',$id_well)->where('id_tools',$id_tools)->where('id_kategori',$id_kategori)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
                
                if(empty($category) && !empty($well) && !empty($tool)){
                    if($page != "1"){
                        
                        $today = date('Y-m-d');
                        $total = $page * 2;
                        $dateFrom = date('Y-m-d', strtotime('+'.$total. 'day', strtotime($today)));
                        $dateTo = date('Y-m-d', strtotime('+2 day', strtotime($dateFrom)));
                        
                    }
                    
                    $tol = Tools::where('tools',$tool)->first();
                    if(!empty($tol)){
                        $id_tools = $tol->id_tools;
                    }else{
                        $id_tools = "";
                    }
                    
                    $exp = explode("-",$well);
                    $well_name = $exp[0];
                    $well_id = $exp[1];
                    
                    $wel = Well::where('nama_sumur',$well_name)->first();
                    if(!empty($wel)){
                        $id_well = $wel->id_sumur;
                    }else{
                        $id_well = "";
                    }
                    
                    $photo = Upload::whereBetween('waktu', [$dateFrom, $dateTo])->where('id_sumur',$id_sumur)->where('no_sumur',$id_well)->where('id_tools',$id_tools)->select(['id_upload', 'foto','waktu'])->get();
            
                    $collection = collect();
                    foreach ($photo as $invoice) {
                            $collection->push([
                                'id' => $invoice->id_upload,
                                'photo' => $invoice->foto,
                                'date' => $invoice->waktu,
                            ]);
                        
                    }
                    
                    $fotos = [];
                    foreach ($collection as $key => $value) {
                        $fotos[$value['date']]['date'] = $value['date'];
                        $fotos[$value['date']]['photos'][$value['id']]['id'] = $value['id'];
                        $fotos[$value['date']]['photos'][$value['id']]['picture'] = $value['photo'];
                    }
                }
            }
            
        }
        
        
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $fotos
    	   ]
    	);
    }
    
    public function detail($id,Request $request)
    {
        
    	$photo = Upload::where('id_upload',$id)->join('sumur','uploadan.id_sumur','=','sumur.id_sumur')->join('tools','uploadan.id_tools','=','tools.id_tools')
    	->join('kategori','uploadan.id_kategori','=','kategori.id_kategori')->join('user','uploadan.id_user','=','user.id_user')->select('uploadan.*', 'sumur.*','tools.tools','user.nama')->first();
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $photo
    	   ]
    	);
    	
    }
    
    public function login(Request $request)
    {
    	$user = $request->username;
    	$password = md5($request->password);
    	
    	$login = User::where('username',$user)->where('password',$password)->select('id_user as id','nama as name')->first();
    	
    	if(empty($login)){
    	    $status = "NO";
    	}
    	else{
    	    $status = "OK";
    	}
    	
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => $status,
                "data" => $login
    	   ]
    	);
    	
    }
    
    public function spinner(Request $request)
    {
        
        $tools = Tools::get();
        $well = Well::get();
        $user = User::select('id_user','nama')->get();
        $kategori = Kategori::get();
    	
    	$spinner = [];
    	$spinner['tools'] = $tools;
    	$spinner['well'] = $well;
    	$spinner['user'] = $user;
    	$spinner['kategori'] = $kategori;
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $spinner
    	   ]
    	);
    	
    }
    
    public function upload(Request $request)
    {

            $image = $request->picture('file');
            $name = $image->getClientOriginalName();                    
            $destinationPath = public_path('/img');
            $image->move($destinationPath, $name);
    
            $up = new Upload();
            $up->foto = $name;
            $up->id_user = $request->userId;
            $up->id_sumur = $request->well;
            $up->id_tools = $request->tool;
            $up->id_kategori = $request->category;
            $up->keterangan = $request->description;
            $up->waktu = $request->date;
            $up->save();
        
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $up
    	   ]
    	);
    	
    }
    
    public function update($id, Request $request)
    {     
            $up = Upload::where('id_upload',$id)->first();
            
            if ($request->hasFile('file')) {
                $image = $request->picture('file');
                $name = $image->getClientOriginalName();                    
                $destinationPath = public_path('/img');
                $image->move($destinationPath, $name);
                $up->foto = $name;
            }
            
            $up->id_sumur = $request->well;
            $up->id_tools = $request->tool;
            $up->id_kategori = $request->category;
            $up->keterangan = $request->description;
            $up->waktu = $request->date;
            $up->save();
        
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $up
    	   ]
    	);
    	
    }
    
    public function delete($id, Request $request)
    {     
            $up = Upload::where('id_upload',$id)->first();
            
            $up->delete();
        
    	
    	return response()->json(
    	   [
    	        "code" => 200,
                "status" => "OK",
                "data" => $up
    	   ]
    	);
    	
    }
    
    public function excel(Request $request)
    {     
        
        Excel::store(new Uploadan(2018), 'invoices.xlsx', public_path('/'));
        return Excel::download(new Uploadan, 'ExcelRecord.xlsx');
    	
    }

   
}

